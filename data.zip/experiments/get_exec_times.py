import sys
import statistics

def get_seconds(v):
    h, m, s = v.split(':')
    return int(s) + int(m)*60 + int(h)*60*60 

# Total number of mixtures: 7_140
# Learned parameters and filtered in 64.8970057964325 s
# Remaining programs: 2471
# LL test: -9.101679446130742
# ROC AUC test: 0.8571428571428572
# PR test: 0.9511183319481639
# real	1m7.890s




nr = 2

datasets = ["bupa", "carc","financial", "mondial", "muta", "pyrimidine", "nba", "sisya", "sisyb", "yeast"]

for dataset in datasets:
    par_learning_time_list = []
    times_list = []
    
    fname = f"mop/{dataset}/mop_{dataset}_{nr}x1.log"
    fp = open(fname, "r")
    lines = fp.read().splitlines()
    fp.close()
    # print(fname)
    for line in lines:
        if line.startswith("Learned parameters and filtered in"):
            tp = line.split("Learned parameters and filtered in")[1].split(' ')[1]
            par_learning_time_list.append(float(tp))
        elif "CEST" in line.split(' '):
            l = line.split(' ')
            t = l[3]
            times_list.append(t)
    par_learning_time_list = par_learning_time_list[:-1]
    dt_list = []    
    i = 0
    for i in range(0, len(times_list) - 1):
        t0 = times_list[i]
        t1 = times_list[i+1]
        v0 = get_seconds(t0)
        v1 = get_seconds(t1)
        delta = v1 - v0
        if delta > 0:
            dt_list.append(delta)

        

    print(
    dataset,
    statistics.mean(par_learning_time_list),
    statistics.mean(dt_list),
    # dt_list
    )


