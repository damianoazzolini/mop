import sys
import statistics

import scipy.stats
import numpy as np

try:
    silent = int(sys.argv[1])
except:
    silent = 0
# for_liftcover = int(sys.argv[2])
# nr = int(sys.argv[1])
# nba = int(sys.argv[2])

def compute_stat(metrics, l0, l1):
    # uso exact perché altrimenti Sample size too small for normal approximation.
    # come dice la guida https://docs.scipy.org/doc/scipy-1.14.0/reference/generated/scipy.stats.wilcoxon.html

    d0 = np.around(np.array(l0) - np.array(l1), decimals=5)
    d = [i for i in d0 if i != 0]
    test = scipy.stats.wilcoxon(d, method="exact")

    return test.pvalue


def main():

    # datasets = ["financial", "mondial", "muta", "nba", "sisya", "sisyb", "yeast"]
    datasets = ["financial", "mondial", "muta", "nba", "sisya", "sisyb", "yeast"]

    for dataset in datasets:

        print(f"{dataset}")
        fname_mop_3x1 = f"mop/{dataset}/mop_{dataset}_3x1.log"
        fname_mop_2x1 = f"mop/{dataset}/mop_{dataset}_2x1.log"
        # em bayes è quasi sempre il migliore
        fname_lift = f"liftcover/{dataset}/liftcover_{dataset}_em_bayes.log"

        if silent != 1:
            print(f"Extracting from {fname_mop_3x1}")
            print(f"Extracting from {fname_mop_2x1}")
            print(f"Extracting from {fname_lift}")

        ll_list_mop_3x1 = []
        rocauc_list_mop_3x1 = []
        pr_list_mop_3x1 = []

        fp = open(fname_mop_3x1, "r")
        lines = fp.read().splitlines()
        fp.close()

        for line in lines:
            if line.startswith("LL test: "):
                ll = line.split("LL test: ")[1]
                ll_list_mop_3x1.append(float(ll))
            elif line.startswith("ROC AUC test: "):
                ra = line.split("ROC AUC test: ")[1]
                rocauc_list_mop_3x1.append(float(ra))            
            elif line.startswith("PR test: "):
                pr = line.split("PR test: ")[1]
                pr_list_mop_3x1.append(float(pr))

        ##################################

        ll_list_mop_2x1 = []
        rocauc_list_mop_2x1 = []
        pr_list_mop_2x1 = []

        fp = open(fname_mop_2x1, "r")
        lines = fp.read().splitlines()
        fp.close()

        for line in lines:
            if line.startswith("LL test: "):
                ll = line.split("LL test: ")[1]
                ll_list_mop_2x1.append(float(ll))
            elif line.startswith("ROC AUC test: "):
                ra = line.split("ROC AUC test: ")[1]
                rocauc_list_mop_2x1.append(float(ra))            
            elif line.startswith("PR test: "):
                pr = line.split("PR test: ")[1]
                pr_list_mop_2x1.append(float(pr))

        ########################

        ll_list_lift = []
        rocauc_list_lift = []
        pr_list_lift = []

        fp = open(fname_lift, "r")
        lines = fp.read().splitlines()
        fp.close()

        for line in lines:
            # LL: -773.7483308534845
            # AUCROC: 0.5
            # AUCPR: 0.2863777089783279
            if line.startswith("LL:"):
                ll = line.split("LL: ")[1]
                ll_list_lift.append(float(ll))
            elif line.startswith("AUCROC:"):
                aucroc = line.split("AUCROC: ")[1]
                rocauc_list_lift.append(float(aucroc))
            elif line.startswith("AUCPR:"):
                aucpr = line.split("AUCPR: ")[1]
                pr_list_lift.append(float(aucpr))


        #######
        # print(ll_list_mop_3x1, ll_list_lift)
        threshold = 0.05
        #         if test.pvalue < threshold:
        #     print(f"{metrics} reject {test.pvalue}: different")
        # else:
        #     print(f"{metrics} accepted {test.pvalue}: equal")
        # print("LL 3x1 - lift ; LL 2x1 - lift ; LL 3x1 - 2x1")
        # print("ROC 3x1 - lift ; ROC 2x1 - lift ; ROC 3x1 - 2x1")
        # print("PR 3x1 - lift ; PR 2x1 - lift ; PR 3x1 - 2x1")

        pv0 = compute_stat("LL 3x1 - lift", ll_list_mop_3x1, ll_list_lift)
        pv1 = compute_stat("LL 2x1 - lift", ll_list_mop_2x1, ll_list_lift)
        pv2 = compute_stat("LL 3x1 - 2x1", ll_list_mop_3x1, ll_list_mop_2x1)
        print(pv0, pv1, pv2)

        pv0 = compute_stat("ROC  3x1 - lift", rocauc_list_mop_3x1, rocauc_list_lift)
        pv1 = compute_stat("ROC 2x1 - lift", rocauc_list_mop_2x1, rocauc_list_lift)
        pv2 = compute_stat("ROC 3x1 - 2x1", rocauc_list_mop_3x1, rocauc_list_mop_2x1)
        print(pv0, pv1, pv2)

        pv0 = compute_stat("PR 3x1 - lift", pr_list_mop_3x1, pr_list_lift)
        pv1 = compute_stat("PR 2x1 - lift", pr_list_mop_2x1, pr_list_lift)
        pv2 = compute_stat("PR 3x1 - 2x1", pr_list_mop_3x1, pr_list_mop_2x1)
        print(pv0, pv1, pv2)


if __name__ == "__main__":
    main()