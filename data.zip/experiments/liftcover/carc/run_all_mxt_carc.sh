./liftcover_run_all_mxt_1.sh
./liftcover_run_all_mxt_2.sh
