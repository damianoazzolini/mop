./liftcover_run_all_mxt_1.sh
./liftcover_run_all_mxt_2.sh
./liftcover_run_all_mxt_3.sh
./liftcover_run_all_mxt_4.sh
