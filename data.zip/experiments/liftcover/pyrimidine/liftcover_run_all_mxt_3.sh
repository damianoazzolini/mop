#!/bin/bash
#SBATCH --job-name=lftpyrimidine3
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 00:30:00
#SBATCH --output=lift_pyrimidine_pyrimidine_3.log

date
time swipl -s ../../../datasets/pyrimidine.pl -g "induce_lift([1, 2, 4],P), test_lift(P,[3],LL,AUCROC,_,AUCPR,_), write('LL: '), writeln(LL), write('AUCROC: '), writeln(AUCROC), write('AUCPR: '), writeln(AUCPR)" -t halt

    