#!/bin/bash
#SBATCH --job-name=lftnba1
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 00:30:00
#SBATCH --output=lift_nba_nba_1.log

date
time swipl -s ../../../datasets/nba.pl -g "induce_lift([2, 3, 4, 5],P), test_lift(P,[1],LL,AUCROC,_,AUCPR,_), write('LL: '), writeln(LL), write('AUCROC: '), writeln(AUCROC), write('AUCPR: '), writeln(AUCPR)" -t halt

    