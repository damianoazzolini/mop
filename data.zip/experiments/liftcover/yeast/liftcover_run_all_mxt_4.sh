#!/bin/bash
#SBATCH --job-name=lftyeast4
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 00:30:00
#SBATCH --output=lift_yeast_yeast_4.log

date
time swipl -s ../../../datasets/yeast.pl -g "induce_lift([1, 2, 3, 5, 6, 7, 8, 9, 10],P), test_lift(P,[4],LL,AUCROC,_,AUCPR,_), write('LL: '), writeln(LL), write('AUCROC: '), writeln(AUCROC), write('AUCPR: '), writeln(AUCPR)" -t halt

    