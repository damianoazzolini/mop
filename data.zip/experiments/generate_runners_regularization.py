import sys

name = sys.argv[1]
n_folds = sys.argv[2]

n_folds_plus_one = int(n_folds) + 1


for gamma in [1,5,10]:
    f_run = open(f"mop/{name}/gamma_{gamma}/run_all.sh", "w")
    for nr in [2,3]:
        f_all = open(f"mop/{name}/gamma_{gamma}/run_all_mxt_{name}_{nr}x1_gamma_{gamma}.sh", "w")
        for reg_type in ["l1", "l2"]:
            for i in range(1, n_folds_plus_one):
                l = list(map(str,range(1,n_folds_plus_one)))
                l.remove(f"{i}")
                ls = ' '.join(l)
                fname = f"{name}_run_all_mxt_{i}_{nr}x1_gamma_{gamma}_{reg_type}.sh"
                fp = open(f"mop/{name}/gamma_{gamma}/{fname}", "w")
                fp.write(f"""#!/bin/bash
date
time mop -f ../../../../datasets/{name}.pl -nm -1 -nr {nr} -nba 1 --train {ls} --test {i} -gamma {gamma} -{reg_type}
            """)
                fp.close()

                f_all.write(f"./{fname} >> {name}_{nr}x1_gamma_{gamma}_{reg_type}.log\n")

        f_run.write(f"./run_all_mxt_{name}_{nr}x1_gamma_{gamma}.sh\n")

    f_all.close()
    f_run.close()

