#!/bin/bash
#SBATCH --job-name=sisyb6
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 08:00:00
#SBATCH --output=sisyb_sisyb_6.log

date
time mop -f ../../../datasets/sisyb.pl -nm -1 -nr 3 -nba 1 --train 1 2 3 4 5 7 8 9 10 --test 6
    