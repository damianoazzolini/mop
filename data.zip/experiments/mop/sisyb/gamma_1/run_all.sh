./run_all_mxt_sisyb_2x1_gamma_1.sh
./run_all_mxt_sisyb_3x1_gamma_1.sh
