#!/bin/bash
date
time mop -f ../../../../datasets/sisyb.pl -nm -1 -nr 3 -nba 1 --train 1 2 3 4 5 6 7 8 9 --test 10 -gamma 1 -l2
            