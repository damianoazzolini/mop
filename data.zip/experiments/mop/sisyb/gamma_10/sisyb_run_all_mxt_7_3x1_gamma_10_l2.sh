#!/bin/bash
date
time mop -f ../../../../datasets/sisyb.pl -nm -1 -nr 3 -nba 1 --train 1 2 3 4 5 6 8 9 10 --test 7 -gamma 10 -l2
            