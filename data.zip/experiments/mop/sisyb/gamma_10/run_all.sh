./run_all_mxt_sisyb_2x1_gamma_10.sh
./run_all_mxt_sisyb_3x1_gamma_10.sh
