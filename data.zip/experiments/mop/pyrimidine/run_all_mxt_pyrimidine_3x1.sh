./pyrimidine_run_all_mxt_1_3x1.sh
./pyrimidine_run_all_mxt_2_3x1.sh
./pyrimidine_run_all_mxt_3_3x1.sh
./pyrimidine_run_all_mxt_4_3x1.sh
