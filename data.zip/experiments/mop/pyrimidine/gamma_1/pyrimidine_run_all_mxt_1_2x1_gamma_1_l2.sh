#!/bin/bash
#!/bin/bash
#SBATCH --job-name=lftpyrimidine1
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 08:00:00
#SBATCH --output=mop_pyrimidine_1_2x1_gamma1_l2.log

date
time mop -f ../../../../datasets/pyrimidine.pl -nm -1 -nr 2 -nba 1 --train 2 3 4 --test 1 -gamma 1 -l2
            