#!/bin/bash
#!/bin/bash
#SBATCH --job-name=lftpyrimidine1
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 08:00:00
#SBATCH --output=mop_pyrimidine_2_3x1_gamma10_l2.log

date
time mop -f ../../../../datasets/pyrimidine.pl -nm -1 -nr 3 -nba 1 --train 1 3 4 --test 2 -gamma 10 -l2
            