cat mop_pyrimidine_1_2x1_gamma10_l1.log >> pyrimidine_2x1_gamma_10_l1.log 
cat mop_pyrimidine_2_2x1_gamma10_l1.log >> pyrimidine_2x1_gamma_10_l1.log 
cat mop_pyrimidine_3_2x1_gamma10_l1.log >> pyrimidine_2x1_gamma_10_l1.log 
cat mop_pyrimidine_4_2x1_gamma10_l1.log >> pyrimidine_2x1_gamma_10_l1.log 

cat mop_pyrimidine_1_2x1_gamma10_l2.log >> pyrimidine_2x1_gamma_10_l2.log 
cat mop_pyrimidine_2_2x1_gamma10_l2.log >> pyrimidine_2x1_gamma_10_l2.log 
cat mop_pyrimidine_3_2x1_gamma10_l2.log >> pyrimidine_2x1_gamma_10_l2.log 
cat mop_pyrimidine_4_2x1_gamma10_l2.log >> pyrimidine_2x1_gamma_10_l2.log 

cat mop_pyrimidine_1_3x1_gamma10_l1.log >> pyrimidine_3x1_gamma_10_l1.log 
cat mop_pyrimidine_2_3x1_gamma10_l1.log >> pyrimidine_3x1_gamma_10_l1.log 
cat mop_pyrimidine_3_3x1_gamma10_l1.log >> pyrimidine_3x1_gamma_10_l1.log 
cat mop_pyrimidine_4_3x1_gamma10_l1.log >> pyrimidine_3x1_gamma_10_l1.log 

cat mop_pyrimidine_1_3x1_gamma10_l2.log >> pyrimidine_3x1_gamma_10_l2.log 
cat mop_pyrimidine_2_3x1_gamma10_l2.log >> pyrimidine_3x1_gamma_10_l2.log 
cat mop_pyrimidine_3_3x1_gamma10_l2.log >> pyrimidine_3x1_gamma_10_l2.log 
cat mop_pyrimidine_4_3x1_gamma10_l2.log >> pyrimidine_3x1_gamma_10_l2.log 
