#!/bin/bash
#!/bin/bash
#SBATCH --job-name=lftpyrimidine1
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 08:00:00
#SBATCH --output=mop_pyrimidine_3_3x1_gamma5_l1.log

date
time mop -f ../../../../datasets/pyrimidine.pl -nm -1 -nr 3 -nba 1 --train 1 2 4 --test 3 -gamma 5 -l1
            