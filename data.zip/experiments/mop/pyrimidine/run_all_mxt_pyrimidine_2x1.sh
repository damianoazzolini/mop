./pyrimidine_run_all_mxt_1_2x1.sh
./pyrimidine_run_all_mxt_2_2x1.sh
./pyrimidine_run_all_mxt_3_2x1.sh
./pyrimidine_run_all_mxt_4_2x1.sh
