#!/bin/bash
#SBATCH --job-name=pyrimidine4
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 08:00:00
#SBATCH --output=pyrimidine_pyrimidine_4.log

date
time mop -f ../../../datasets/pyrimidine.pl -nm -1 -nr 3 -nba 1 --train 1 2 3 --test 4
    