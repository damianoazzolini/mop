#!/bin/bash
date
time mop -f ../../../../datasets/muta.pl -nm -1 -nr 3 -nba 1 --train 1 2 3 4 5 6 7 8 10 --test 9 -gamma 5 -l1
            