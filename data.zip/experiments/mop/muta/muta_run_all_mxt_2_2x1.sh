#!/bin/bash
#SBATCH --job-name=muta2
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 08:00:00
#SBATCH --output=muta_muta_2.log

date
time mop -f ../../../datasets/muta.pl -nm -1 -nr 2 -nba 1 --train 1 3 4 5 6 7 8 9 10 --test 2
    