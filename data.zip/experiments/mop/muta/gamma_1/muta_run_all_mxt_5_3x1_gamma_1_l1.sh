#!/bin/bash
date
time mop -f ../../../../datasets/muta.pl -nm -1 -nr 3 -nba 1 --train 1 2 3 4 6 7 8 9 10 --test 5 -gamma 1 -l1
            