./run_all_mxt_muta_2x1_gamma_1.sh
./run_all_mxt_muta_3x1_gamma_1.sh
