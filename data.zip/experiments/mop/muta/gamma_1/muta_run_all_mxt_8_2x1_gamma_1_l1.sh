#!/bin/bash
date
time mop -f ../../../../datasets/muta.pl -nm -1 -nr 2 -nba 1 --train 1 2 3 4 5 6 7 9 10 --test 8 -gamma 1 -l1
            