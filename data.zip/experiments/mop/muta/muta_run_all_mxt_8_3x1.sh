#!/bin/bash
#SBATCH --job-name=muta8
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 08:00:00
#SBATCH --output=muta_muta_8.log

date
time mop -f ../../../datasets/muta.pl -nm -1 -nr 3 -nba 1 --train 1 2 3 4 5 6 7 9 10 --test 8
    