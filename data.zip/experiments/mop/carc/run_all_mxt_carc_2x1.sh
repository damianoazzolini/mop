./carc_run_all_mxt_1_2x1.sh
./carc_run_all_mxt_2_2x1.sh
