./carc_run_all_mxt_1_3x1.sh
./carc_run_all_mxt_2_3x1.sh
