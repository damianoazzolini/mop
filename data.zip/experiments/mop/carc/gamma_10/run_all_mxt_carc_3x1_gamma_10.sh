./carc_run_all_mxt_1_3x1_gamma_10_l1.sh >> carc_3x1_gamma_10_l1.log
./carc_run_all_mxt_2_3x1_gamma_10_l1.sh >> carc_3x1_gamma_10_l1.log
./carc_run_all_mxt_1_3x1_gamma_10_l2.sh >> carc_3x1_gamma_10_l2.log
./carc_run_all_mxt_2_3x1_gamma_10_l2.sh >> carc_3x1_gamma_10_l2.log
