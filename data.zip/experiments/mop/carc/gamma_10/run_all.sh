./run_all_mxt_carc_2x1_gamma_10.sh
./run_all_mxt_carc_3x1_gamma_10.sh
