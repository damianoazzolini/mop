#!/bin/bash
date
time mop -f ../../../../datasets/carc.pl -nm -1 -nr 2 -nba 1 --train 1 --test 2 -gamma 10 -l1
            