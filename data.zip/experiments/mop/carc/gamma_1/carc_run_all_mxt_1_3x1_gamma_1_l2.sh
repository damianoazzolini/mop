#!/bin/bash
date
time mop -f ../../../../datasets/carc.pl -nm -1 -nr 3 -nba 1 --train 2 --test 1 -gamma 1 -l2
            