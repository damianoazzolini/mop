./carc_run_all_mxt_1_2x1_gamma_1_l1.sh >> carc_2x1_gamma_1_l1.log
./carc_run_all_mxt_2_2x1_gamma_1_l1.sh >> carc_2x1_gamma_1_l1.log
./carc_run_all_mxt_1_2x1_gamma_1_l2.sh >> carc_2x1_gamma_1_l2.log
./carc_run_all_mxt_2_2x1_gamma_1_l2.sh >> carc_2x1_gamma_1_l2.log
