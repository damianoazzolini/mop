import sys

name = sys.argv[1]
n_folds = sys.argv[2]

for_liftcover = sys.argv[3] # 0 no, 1 yes
# n_mixtures = int(sys.argv[4]) # -1 all

nr = int(sys.argv[4])
nba = int(sys.argv[5])

n_folds_plus_one = int(n_folds) + 1

if for_liftcover == "1":
    f_all = open(f"liftcover/{name}/run_all_mxt_{name}.sh", "w")
    for i in range(1, n_folds_plus_one):
        l = list(range(1, n_folds_plus_one))
        l.remove(i)
        fname = f"liftcover_run_all_mxt_{i}.sh"
        fp = open(f"liftcover/{name}/{fname}", "w")
        fp.write(f"""#!/bin/bash
#SBATCH --job-name=lft{name}{i}
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 00:30:00
#SBATCH --output=lift_{name}_{name}_{i}.log

date
time swipl -s ../../../datasets/{name}.pl -g "induce_lift({l},P), test_lift(P,[{i}],LL,AUCROC,_,AUCPR,_), write('LL: '), writeln(LL), write('AUCROC: '), writeln(AUCROC), write('AUCPR: '), writeln(AUCPR)" -t halt

    """)
        fp.close()

        f_all.write(f"./{fname}\n")

else:
    f_all = open(f"mop/{name}/run_all_mxt_{name}_{nr}x{nba}.sh", "w")

    # output_name = ""
    # if int(n_mixtures) == -1:
    output_name = f"{name}_{name}"
    # else:
    #     output_name = f"{name}_{name}_{n_mixtures}"

    for i in range(1, n_folds_plus_one):
        l = list(map(str,range(1,n_folds_plus_one)))
        l.remove(f"{i}")
        ls = ' '.join(l)
        fname = f"{name}_run_all_mxt_{i}_{nr}x{nba}.sh"
        fp = open(f"mop/{name}/{fname}", "w")
        fp.write(f"""#!/bin/bash
#SBATCH --job-name={name}{i}
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=compute
#SBATCH -t 08:00:00
#SBATCH --output={output_name}_{i}.log

date
time mop -f ../../../datasets/{name}.pl -nm -1 -nr {nr} -nba {nba} --train {ls} --test {i}
    """)
        fp.close()

        f_all.write(f"./{fname}\n")

f_all.close()
