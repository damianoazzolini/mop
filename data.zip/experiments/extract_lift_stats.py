import sys
import statistics

dataset = sys.argv[1]


# Total number of mixtures: 7_140
# Learned parameters and filtered in 64.8970057964325 s
# Remaining programs: 2471
# LL test: -9.101679446130742
# ROC AUC test: 0.8571428571428572
# PR test: 0.9511183319481639
# real	1m7.890s

# real_time_list = []


modes = ["em_bayes", "em_l1", "em_l2", "gd"]
print(modes)

ll_all = []
roc_all = []
pr_all = []

for m in modes:
    fname = f"liftcover/{dataset}/liftcover_{dataset}_{m}.log"

    # print(f"Extracting from {fname}")

    fp = open(fname, "r")
    lines = fp.read().splitlines()
    fp.close()

    ll_list = []
    rocauc_list = []
    pr_list = []


    for line in lines:
        # LL: -773.7483308534845
        # AUCROC: 0.5
        # AUCPR: 0.2863777089783279
        if line.startswith("LL:"):
            ll = line.split("LL: ")[1]
            ll_list.append(float(ll))
        elif line.startswith("AUCROC:"):
            aucroc = line.split("AUCROC: ")[1]
            rocauc_list.append(float(aucroc))
        elif line.startswith("AUCPR:"):
            aucpr = line.split("AUCPR: ")[1]
            pr_list.append(float(aucpr))

    ll_all.append(statistics.mean(ll_list))
    roc_all.append(statistics.mean(rocauc_list))
    pr_all.append(statistics.mean(pr_list))

    print(
    statistics.mean(ll_list),
    # statistics.variance(ll_list),
    statistics.mean(rocauc_list),
    # statistics.variance(rocauc_list),
    statistics.mean(pr_list)
    # statistics.variance(pr_list)
    )

print(*ll_all, *roc_all, *pr_all)