import sys
import statistics

dataset = sys.argv[1]
for_liftcover = int(sys.argv[2])
nr = int(sys.argv[3])
nba = int(sys.argv[4])
fold_stats = int(sys.argv[5]) # 1 prints all the values in the list

if for_liftcover != 1:
    fname = f"mop/{dataset}/mop_{dataset}_{nr}x{nba}.log"
else:
    fname = f"liftcover/{dataset}/liftcover_{dataset}.log"

print(f"Extracting from {fname}")

# Total number of mixtures: 7_140
# Learned parameters and filtered in 64.8970057964325 s
# Remaining programs: 2471
# LL test: -9.101679446130742
# ROC AUC test: 0.8571428571428572
# PR test: 0.9511183319481639
# real	1m7.890s

n_mixtures_list = [] # useless because the number is always the same but ok
par_learning_time_list = []
remaining_programs_list = []
ll_list = []
rocauc_list = []
pr_list = []
# real_time_list = []

fp = open(fname, "r")
lines = fp.read().splitlines()
fp.close()

if for_liftcover != 1:
    for line in lines:
        if line.startswith("Total number of mixtures:"):
            nm = line.split("Total number of mixtures: ")[1]
            n_mixtures_list.append(int(nm))
        elif line.startswith("Learned parameters and filtered in"):
            tp = line.split("Learned parameters and filtered in")[1].split(' ')[1]
            par_learning_time_list.append(float(tp))
        elif line.startswith("Remaining programs: "):
            np = line.split("Remaining programs: ")[1].split(" ")[0]
            remaining_programs_list.append(int(np))
        elif line.startswith("LL test: "):
            ll = line.split("LL test: ")[1]
            ll_list.append(float(ll))
        elif line.startswith("ROC AUC test: "):
            ra = line.split("ROC AUC test: ")[1]
            rocauc_list.append(float(ra))            
        elif line.startswith("PR test: "):
            pr = line.split("PR test: ")[1]
            pr_list.append(float(pr))
        elif line.startswith("real"):
            t = line.split("\t")[1]
            m = int(t.split('m')[0])
            s = float(t.split('m')[1][:-1])
            tt = m * 60 + s
            # real_time_list.append(tt)

    if fold_stats == 1:
        print("LL list")
        print(*ll_list)
        print("ROC list")
        print(*rocauc_list)
        print("PR list")
        print(*pr_list)

    print(n_mixtures_list[0],
    statistics.mean(par_learning_time_list),
    statistics.variance(par_learning_time_list),
    statistics.mean(remaining_programs_list),
    statistics.variance(remaining_programs_list),
    statistics.mean(ll_list),
    statistics.variance(ll_list),
    statistics.mean(rocauc_list),
    statistics.variance(rocauc_list),
    statistics.mean(pr_list),
    statistics.variance(pr_list)
    # statistics.mean(real_time_list),
    # statistics.variance(real_time_list)
    )
else:
    for line in lines:
        # LL: -773.7483308534845
        # AUCROC: 0.5
        # AUCPR: 0.2863777089783279
        if line.startswith("LL:"):
            ll = line.split("LL: ")[1]
            ll_list.append(float(ll))
        elif line.startswith("AUCROC:"):
            aucroc = line.split("AUCROC: ")[1]
            rocauc_list.append(float(aucroc))
        elif line.startswith("AUCPR:"):
            aucpr = line.split("AUCPR: ")[1]
            pr_list.append(float(aucpr))
    
    if fold_stats == 1:
        print("LL list")
        print(*ll_list)
        print("ROC list")
        print(*rocauc_list)
        print("PR list")
        print(*pr_list)

    print(
    statistics.mean(ll_list),
    statistics.variance(ll_list),
    statistics.mean(rocauc_list),
    statistics.variance(rocauc_list),
    statistics.mean(pr_list),
    statistics.variance(pr_list)
    )